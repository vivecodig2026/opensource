﻿#requires -Version 5.1
<# WindowsCare 1.0.1. Local, interactivo y sin telemetria. Ver LEEME.txt. #>
[CmdletBinding()]
param(
    [ValidateSet('Menu','Checkpoint','SystemTemp','Repair','ScanDisk','Optimize','Signatures','QuickScan','FullScan','OfflineScan')]
    [string]$Task = 'Menu'
)
$ErrorActionPreference = 'Stop'
if ($env:OS -ne 'Windows_NT') { throw 'Esta herramienta requiere Windows.' }
if (-not [Environment]::Is64BitProcess -and [Environment]::Is64BitOperatingSystem) {
    throw 'Abra el lanzador CMD para usar PowerShell de 64 bits.'
}
$script:Self = $PSCommandPath
$script:Admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
$script:LogRoot = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'WindowsCare\Informes'
$null = New-Item -ItemType Directory -Path $script:LogRoot -Force
$script:Log = Join-Path $script:LogRoot ('Informe_{0}_{1}.txt' -f (Get-Date -Format 'yyyyMMdd_HHmmss'),$PID)
$script:RestartSuggested = $false
function Note([string]$Message) {
    Write-Host $Message
    Add-Content -LiteralPath $script:Log -Value ('[{0}] {1}' -f (Get-Date -Format 's'),$Message) -Encoding UTF8
}
function Confirm([string]$Message) { return ((Read-Host "$Message Escriba SI para continuar") -ceq 'SI') }
function Pause-Menu { $null = Read-Host 'Pulse Entrar para volver' }
function Display($Value) { Note ($Value | Out-String -Width 160) }
function Free-Space {
    @(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' | ForEach-Object {
        [pscustomobject]@{Unidad=$_.DeviceID; LibreGB=[math]::Round($_.FreeSpace/1073741824,2); TotalGB=[math]::Round($_.Size/1073741824,2)}
    })
}
function Restart-State {
    $reasons = New-Object 'System.Collections.Generic.List[string]'
    try {
        foreach ($p in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending','HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired')) {
            if (Test-Path -LiteralPath $p) { $reasons.Add(($p.Split('\')[-2])) }
        }
        $r = Get-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager'
        if ($r.PSObject.Properties['PendingFileRenameOperations'] -and $r.PendingFileRenameOperations) { $reasons.Add('Operaciones de archivos pendientes') }
        if ($script:RestartSuggested) { $reasons.Add('Una herramienta solicito reiniciar') }
        if ($reasons.Count) { Note ('Reinicio pendiente o recomendado: ' + ($reasons -join ', ')) }
        else { Note 'No se detectaron indicadores comunes de reinicio pendiente; no es una comprobacion exhaustiva.' }
    } catch { Note 'No se pudo determinar completamente el estado de reinicio.' }
}
function Operation([string]$Name,[scriptblock]$Body) {
    Note "INICIO: $Name"
    try {
        Note 'Espacio libre antes:'; Display (Free-Space)
        & $Body
        Note "FIN: $Name (revise resultados y omisiones anteriores)."
    } catch {
        # No registrar mensajes arbitrarios que puedan contener rutas personales.
        Note ("ERROR en {0}: {1}; categoria {2}; HRESULT {3}." -f $Name,$_.Exception.GetType().Name,$_.CategoryInfo.Category,$_.Exception.HResult)
        Write-Warning 'La operacion no se completo. Consulte tambien la salida nativa, si existe.'
    } finally {
        try { Note 'Espacio libre despues:'; Display (Free-Space) } catch { Note 'Espacio libre no disponible.' }
        Restart-State
    }
}
function Checkpoint {
    Note 'Intentando crear punto de restauracion. No sustituye una copia de seguridad ni recupera necesariamente archivos borrados.'
    try {
        $before = @(Get-ComputerRestorePoint -ErrorAction Stop | Select-Object -ExpandProperty SequenceNumber)
        Checkpoint-Computer -Description ('WindowsCare ' + (Get-Date -Format 's')) -RestorePointType MODIFY_SETTINGS -WarningAction SilentlyContinue -ErrorAction Stop
        $after = @(Get-ComputerRestorePoint -ErrorAction Stop | Where-Object { $before -notcontains $_.SequenceNumber })
        if ($after.Count) { Note 'Punto de restauracion nuevo verificado.' }
        else { Note 'No se verifico un punto nuevo. Puede existir un limite de frecuencia o proteccion deshabilitada.' }
    } catch { Note 'No se pudo crear/verificar un punto de restauracion. No se modifico la configuracion de proteccion.' }
}
function Run-Admin([string]$Action) {
    if ($script:Admin) { Invoke-Task $Action; return }
    Note "La accion $Action requiere administrador. Se abrira una ventana con UAC; puede cancelar."
    # Solo nombres del ValidateSet y ruta propia; ningun texto ingresado se ejecuta.
    $allowed = @('Checkpoint','SystemTemp','Repair','ScanDisk','Optimize','Signatures','QuickScan','FullScan','OfflineScan')
    if ($allowed -notcontains $Action) { throw 'Accion no permitida.' }
    if ($script:Self.Contains('"')) { throw 'Ruta de script invalida.' }
    $argsText = '-NoLogo -NoProfile -ExecutionPolicy Bypass -File "{0}" -Task {1}' -f $script:Self,$Action
    try {
        $p = Start-Process -FilePath "$PSHOME\powershell.exe" -ArgumentList $argsText -Verb RunAs -PassThru -Wait
        Note "Ventana administrativa cerrada. Codigo de proceso: $($p.ExitCode). El detalle esta en su informe, no en este codigo."
        Note 'Si uso credenciales de otra cuenta, su informe estara en LocalAppData de esa cuenta.'
    } catch { Note 'Elevacion cancelada o no disponible. No se ejecuto la accion administrativa.' }
}
function Ensure-NoRepair {
    if (@(Get-Process -Name 'dism','sfc','chkdsk','TiWorker','TrustedInstaller' -ErrorAction SilentlyContinue).Count) {
        Write-Warning 'Hay reparacion o mantenimiento de Windows activo. Espere y vuelva a intentarlo.'
        throw 'Mantenimiento activo.'
    }
}
function Native([string]$Exe,[string[]]$Arguments,[string]$Label) {
    $outFile = Join-Path $script:LogRoot ('{0}_{1}_{2}.log' -f $Label,(Get-Date -Format 'yyyyMMdd_HHmmss'),$PID)
    Note "$Label en ejecucion. Espere; algunos tramos no muestran progreso."
    & (Join-Path "$env:SystemRoot\System32" $Exe) @Arguments 2>&1 | Tee-Object -FilePath $outFile | Out-Host
    $code = $LASTEXITCODE
    Note "$Label termino con codigo $code. Salida nativa: $outFile"
    return [int]$code
}
function Defender-Status {
    try {
        Display (Get-CimInstance -Namespace root/SecurityCenter2 -ClassName AntivirusProduct | Select-Object 'displayName','productState')
        Note 'El registro de proveedores puede contener entradas antiguas. No se deduce el antivirus activo solo de esta lista.'
    } catch { Note 'No se pudo consultar el registro de proveedores de antivirus.' }
    try {
        $s = Get-MpComputerStatus
        Display ($s | Select-Object 'AMRunningMode','AMServiceEnabled','AntivirusEnabled','RealTimeProtectionEnabled','AntivirusSignatureLastUpdated','QuickScanStartTime','QuickScanEndTime','FullScanStartTime','FullScanEndTime')
    } catch { Note 'Estado de Defender no disponible en esta cuenta o equipo.' }
}
function Require-Defender {
    $s = Get-MpComputerStatus
    if (-not $s.AMServiceEnabled -or -not $s.AntivirusEnabled -or -not $s.RealTimeProtectionEnabled) {
        Write-Warning 'Defender no esta completamente activo. Revise Seguridad de Windows; no se forzara su activacion.'
        throw 'Defender no activo.'
    }
    if ($s.PSObject.Properties['AMRunningMode'] -and $s.AMRunningMode -ne 'Normal') { Write-Warning 'Defender no esta en modo Normal; no se interferira con otro antivirus.'; throw 'Modo Defender no disponible.' }
    return $s
}
function Threat-History {
    Note 'Historial de detecciones: puede contener incidentes anteriores; no implica infeccion actual.'
    $d = @(Get-MpThreatDetection | Sort-Object InitialDetectionTime -Descending | Select-Object -First 20 'ThreatID','InitialDetectionTime','LastThreatStatusChangeTime','ActionSuccess','CleaningActionID','ThreatStatusID')
    if ($d.Count) { Display $d } else { Note 'No hay detecciones disponibles en este historial. Esto no garantiza ausencia de amenazas.' }
    Note 'ActionSuccess y los identificadores son valores reales de Defender. Para detalles y acciones pendientes, abra Historial de proteccion en Seguridad de Windows.'
}
function Diagnose {
    $os = Get-CimInstance Win32_OperatingSystem
    Display ($os | Select-Object 'Caption','Version','BuildNumber','LastBootUpTime')
    Display ([pscustomobject]@{RAMTotalGB=[math]::Round($os.TotalVisibleMemorySize/1048576,2); RAMDisponibleGB=[math]::Round($os.FreePhysicalMemory/1048576,2)})
    Display (Free-Space)
    try { Display (Get-PhysicalDisk | Select-Object 'DeviceId','MediaType','BusType','HealthStatus',@{n='TamanoGB';e={[math]::Round($_.Size/1073741824,1)}}) } catch { Note 'Tipo/estado de almacenamiento no disponible. No se infiere SSD por el nombre.' }
    Note 'Procesos con mayor memoria de trabajo (incluye memoria compartida):'
    Display (Get-Process | Sort-Object WorkingSet64 -Descending | Select-Object -First 8 'ProcessName','Id',@{n='MemoriaMB';e={[math]::Round($_.WorkingSet64/1048576,1)}})
    Note 'Muestreando CPU durante unos 3 segundos, normalizada por procesadores logicos.'
    $samples = @{}
    foreach ($p in Get-Process) {
        try { $samples[$p.Id] = @{CPU=$p.TotalProcessorTime.TotalSeconds; Start=$p.StartTime.ToUniversalTime().Ticks} } catch { }
    }
    $timer = [Diagnostics.Stopwatch]::StartNew()
    Start-Sleep -Seconds 3
    $elapsed = $timer.Elapsed.TotalSeconds
    $cpuRows = foreach ($p in Get-Process) {
        try {
            $old = $samples[$p.Id]
            if ($old -and $old.Start -eq $p.StartTime.ToUniversalTime().Ticks) {
                $v = 100*($p.TotalProcessorTime.TotalSeconds-$old.CPU)/($elapsed*[Environment]::ProcessorCount)
                [pscustomobject]@{Proceso=$p.ProcessName; PID=$p.Id; CPU_Porcentaje=[math]::Round([math]::Min(100,[math]::Max(0,$v)),1)}
            }
        } catch { }
    }
    Display ($cpuRows | Sort-Object CPU_Porcentaje -Descending | Select-Object -First 8)
    Note 'Es una muestra aproximada, no el uso sostenido. Procesos inaccesibles o muy breves pueden no aparecer.'
    if ($os.FreePhysicalMemory/$os.TotalVisibleMemorySize -lt 0.15) { Note 'Dato: menos del 15% de RAM disponible en esta muestra. Recomendacion: revisar aplicaciones antes de ampliar memoria.' }
    foreach ($d in Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3') {
        if ($d.Size -gt 0 -and $d.FreeSpace/$d.Size -lt 0.15) { Note "Dato: poco espacio libre en $($d.DeviceID). Recomendacion: revisar almacenamiento y simular limpieza." }
    }
    Note 'Un diagnostico breve no demuestra por si solo la causa de lentitud ni descarta fallos fisicos.'
    Defender-Status
    Restart-State
}
# Eliminacion por handle: bloquea renombrado de ancestros, rechaza reparse points,
# comprueba antiguedad bajo bloqueo exclusivo y marca SOLO ese archivo para borrar.
function Load-SafeDelete {
    if ('WindowsCare.SafeDelete' -as [type]) { return }
    Add-Type -TypeDefinition @'
using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;
namespace WindowsCare {
 public static class SafeDelete {
  [StructLayout(LayoutKind.Sequential)] struct Info {
   public uint Attr; public System.Runtime.InteropServices.ComTypes.FILETIME Created,Accessed,Written;
   public uint Serial,SizeHigh,SizeLow,Links,IndexHigh,IndexLow;
  }
  [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
  static extern SafeFileHandle CreateFile(string p,uint a,uint s,IntPtr sec,uint mode,uint flags,IntPtr tpl);
  [DllImport("kernel32.dll", SetLastError=true)] static extern bool GetFileInformationByHandle(SafeFileHandle h,out Info i);
  [DllImport("kernel32.dll", SetLastError=true)] static extern bool SetFileInformationByHandle(SafeFileHandle h,int c,ref int data,uint size);
  static Info Inspect(SafeFileHandle h) {
   Info i; if(h.IsInvalid || !GetFileInformationByHandle(h,out i)) throw new Win32Exception(Marshal.GetLastWin32Error());
   if((i.Attr & 0x400)!=0) throw new IOException("Reparse point"); return i;
  }
  public static long DeleteOld(string root,string file,DateTime cutoff) {
   root=Path.GetFullPath(root).TrimEnd('\\'); file=Path.GetFullPath(file);
   if(root.Length<4 || !file.StartsWith(root+"\\",StringComparison.OrdinalIgnoreCase)) throw new IOException("Outside root");
   var locks=new List<SafeFileHandle>();
   try {
    string volume=Path.GetPathRoot(file), current=volume;
    string parent=Path.GetDirectoryName(file);
    // Keep every ancestor open without FILE_SHARE_DELETE to prevent substitution.
    var parts=new List<string>(); parts.Add(volume);
    foreach(string part in parent.Substring(volume.Length).Split(new[]{'\\'},StringSplitOptions.RemoveEmptyEntries)) { current=Path.Combine(current,part); parts.Add(current); }
    foreach(string dir in parts) {
     var h=CreateFile(dir,0x80,3,IntPtr.Zero,3,0x02200000,IntPtr.Zero); locks.Add(h);
     if((Inspect(h).Attr & 0x10)==0) throw new IOException("Not a directory");
    }
    using(var h=CreateFile(file,0x10080,0,IntPtr.Zero,3,0x00200000,IntPtr.Zero)) {
     Info i=Inspect(h); if((i.Attr & 0x10)!=0 || i.Links!=1) throw new IOException("Directory or hard link");
     long ft=((long)(uint)i.Written.dwHighDateTime<<32)|(uint)i.Written.dwLowDateTime;
     if(DateTime.FromFileTimeUtc(ft)>=cutoff.ToUniversalTime()) throw new IOException("Too recent");
     int flag=1; if(!SetFileInformationByHandle(h,4,ref flag,4)) throw new Win32Exception(Marshal.GetLastWin32Error());
     return ((long)i.SizeHigh<<32)|i.SizeLow;
    }
   } finally { for(int j=locks.Count-1;j>=0;j--) locks[j].Dispose(); }
  }
 }
}
'@
}
function Allowed-Root([bool]$System) {
    # Deliberadamente no usar TEMP/TMP configurables ni permitir rutas ingresadas.
    $root = if ($System) { Join-Path $env:SystemRoot 'Temp' } else { Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'Temp' }
    $root = [IO.Path]::GetFullPath($root).TrimEnd('\')
    if ($root.Length -lt 4 -or $root -eq [IO.Path]::GetPathRoot($root).TrimEnd('\')) { throw 'Raiz insegura.' }
    $dir = Get-Item -LiteralPath $root -Force
    while ($null -ne $dir) {
        if (-not $dir.PSIsContainer -or ($dir.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Ruta temporal redirigida o no segura; se omite.' }
        $dir = $dir.Parent
    }
    return $root
}
function Candidates([string]$Root,[datetime]$Cutoff) {
    $stack = New-Object 'System.Collections.Generic.Stack[string]'
    $stack.Push($Root)
    while ($stack.Count) {
        $current = $stack.Pop()
        try {
            # Comprobar todos los ancestros antes de enumerar; nunca -Recurse.
            $dir = Get-Item -LiteralPath $current -Force
            $valid = $true
            while ($null -ne $dir) {
                if ($dir.Attributes -band [IO.FileAttributes]::ReparsePoint) { $valid=$false; break }
                $dir=$dir.Parent
            }
            if (-not $valid) { continue }
            foreach ($item in Get-ChildItem -LiteralPath $current -Force -ErrorAction Stop) {
                if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { continue }
                if ($item.PSIsContainer) { $stack.Push($item.FullName) }
                elseif ($item.LastWriteTimeUtc -lt $Cutoff) { $item }
            }
        } catch { $script:SkippedDirectories++ }
    }
}
function Clean-Temp([bool]$System) {
    $root = Allowed-Root $System
    $cutoff = [datetime]::UtcNow.AddDays(-7)
    $script:SkippedDirectories=0
    Note "Simulacion: $root"
    Note 'Solo archivos sin modificaciones en mas de siete dias. No se eliminan carpetas.'
    $files = @(Candidates $root $cutoff)
    $bytes = ($files | Measure-Object Length -Sum).Sum
    Note ('Candidatos: {0}; tamano logico estimado: {1:N2} MB; carpetas inaccesibles: {2}.' -f $files.Count,($bytes/1048576),$script:SkippedDirectories)
    Note 'El espacio recuperado puede ser menor por bloqueos, compresion y cambios posteriores. No se registran nombres de archivos.'
    if (-not $files.Count -or -not (Confirm '¿Eliminar estos temporales? Responda cualquier otra cosa para conservar solo la simulacion.')) { Note 'Simulacion finalizada sin borrar.'; return }
    if ($script:Admin) { Checkpoint } else { Run-Admin 'Checkpoint' }
    if (-not (Confirm 'Revise el resultado del punto de restauracion. ¿Continuar con el borrado?')) { Note 'Borrado cancelado.'; return }
    Load-SafeDelete
    $deleted=0; $skipped=0; [long]$released=0
    foreach ($f in $files) {
        try { $released += [WindowsCare.SafeDelete]::DeleteOld($root,$f.FullName,$cutoff); $deleted++ }
        catch { $skipped++ }
        if ((($deleted+$skipped) % 100) -eq 0) { Write-Host ("Revisados {0} de {1}" -f ($deleted+$skipped),$files.Count) }
    }
    Note ('Eliminados: {0}; omitidos (bloqueados, recientes, enlaces, permisos u otro error): {1}; bytes logicos eliminados: {2}.' -f $deleted,$skipped,$released)
}
function Repair-Windows {
    Ensure-NoRepair
    Note 'DISM puede descargar componentes. SFC se ejecuta despues de DISM si este termina correctamente. No se reinicia el equipo.'
    if (-not (Confirm '¿Reparar componentes y archivos de Windows?')) { return }
    Checkpoint
    Ensure-NoRepair
    $code=Native 'dism.exe' @('/Online','/Cleanup-Image','/RestoreHealth','/NoRestart') 'DISM'
    if ($code -eq 3010) { $script:RestartSuggested=$true; Note 'DISM requiere reinicio. Reinicie manualmente y vuelva a reparar antes de ejecutar SFC.'; return }
    if ($code -ne 0) { Note 'DISM no termino correctamente. SFC se omite. Puede necesitar Internet o un medio de instalacion compatible; consulte el registro DISM.'; return }
    Note 'DISM termino correctamente. Iniciando SFC.'
    $sfc=Native 'sfc.exe' @('/scannow') 'SFC'
    if ($sfc -eq 0) { Note 'SFC termino sin error de proceso. Su codigo no certifica ausencia de corrupcion: lea el resumen de SFC y CBS.log.' }
    else { Note "SFC devolvio ${sfc}: no se considera una reparacion verificada. Revise salida y CBS.log." }
    Note "Registros oficiales conservados: $env:SystemRoot\Logs\DISM\dism.log y $env:SystemRoot\Logs\CBS\CBS.log."
}
function Pick-Volume {
    $vols=@(Get-Volume | Where-Object { $_.DriveLetter -and $_.DriveType -eq 'Fixed' })
    Display ($vols | Select-Object 'DriveLetter','FileSystem','HealthStatus')
    $letter=(Read-Host 'Letra de unidad, por ejemplo C; vacio cancela').Trim().ToUpperInvariant()
    if ($letter -notmatch '^[A-Z]$') { return $null }
    return ($vols | Where-Object { [string]$_.DriveLetter -eq $letter } | Select-Object -First 1)
}
function Scan-Disk {
    Ensure-NoRepair
    $v=Pick-Volume
    if (-not $v) { return }
    if ($v.FileSystem -ne 'NTFS') { Note 'Esta funcion solo ejecuta CHKDSK /scan en NTFS. No se fuerza otro modo.'; return }
    Note 'Comprobacion NTFS en linea; Windows puede aplicar correcciones en linea. No se desmonta ni se agenda un reinicio.'
    if (-not (Confirm '¿Comprobar esta unidad?')) { return }
    Checkpoint
    Ensure-NoRepair
    $code=Native 'chkdsk.exe' @(("{0}:" -f $v.DriveLetter),'/scan') 'CHKDSK'
    switch ($code) {
        0 { Note 'CHKDSK no encontro errores.' }
        1 { Note 'CHKDSK informa errores encontrados y corregidos; revise su resumen.' }
        2 { Note 'CHKDSK informa limpieza o una condicion que requiere revisar su salida.' }
        3 { Note 'CHKDSK no pudo comprobar o corregir completamente el volumen.' }
        default { Note "Codigo CHKDSK no previsto: $code; revise el registro." }
    }
    Note 'Si CHKDSK solicita reparacion fuera de linea: respalde datos y use Propiedades de unidad > Herramientas > Comprobar. Esta utilidad no desmonta ni programa reparaciones de arranque.'
}
function Optimize-Disk {
    Ensure-NoRepair
    $v=Pick-Volume
    if (-not $v) { return }
    Note 'Windows seleccionara la operacion compatible con el medio. No se fuerza Defrag sobre SSD.'
    if (-not (Confirm '¿Optimizar la unidad seleccionada?')) { return }
    Checkpoint
    Optimize-Volume -DriveLetter $v.DriveLetter -Verbose -ErrorAction Stop
    Note 'La solicitud de optimizacion termino; esto no demuestra un aumento de velocidad.'
}
function Defender-Action([string]$Action) {
    $null=Require-Defender
    Defender-Status
    Note 'Defender aplica sus politicas de cuarentena/remediacion. Ningun analisis garantiza detectar todas las amenazas.'
    if ($Action -eq 'OfflineScan') {
        Note 'Se requiere un entorno de recuperacion WinRE habilitado. No se modifica su configuracion.'
        $null=Native 'reagentc.exe' @('/info') 'WinRE'
        Note 'Revise arriba si Windows RE aparece habilitado. Si no lo esta, cancele y consulte soporte antes de continuar.'
        Note 'ATENCION: este analisis REINICIA el equipo. Guarde todo y tenga disponible su clave de recuperacion BitLocker si usa cifrado.'
        if ((Read-Host 'Escriba REINICIAR Y ANALIZAR para autorizar el reinicio') -cne 'REINICIAR Y ANALIZAR') { return }
        Checkpoint
        Note 'Autorizacion explicita registrada para analisis sin conexion y reinicio.'
        Start-MpWDOScan -ErrorAction Stop
        return
    }
    if ($Action -eq 'Signatures') {
        if (-not (Confirm 'Actualizar firmas requiere Internet. ¿Actualizar?')) { return }
        Checkpoint
        Update-MpSignature -ErrorAction Stop
        Note 'Actualizacion solicitada correctamente. Version y fecha actuales:'
        Display (Get-MpComputerStatus | Select-Object 'AntivirusSignatureVersion','AntivirusSignatureLastUpdated')
    } else {
        $kind=if ($Action -eq 'QuickScan') { 'QuickScan' } else { 'FullScan' }
        if (-not (Confirm "¿Ejecutar $kind? Puede tardar y consumir recursos; Defender puede remediar detecciones.")) { return }
        Checkpoint
        Note 'Ejecutando analisis. No se presenta porcentaje estimado.'
        Start-MpScan -ScanType $kind -ErrorAction Stop
        Note 'La llamada a Defender termino. Compruebe fechas y resultado en Seguridad de Windows.'
        Defender-Status
        Threat-History
    }
}
function Invoke-Task([string]$Action) {
    if (-not $script:Admin) { throw 'Se requiere administrador.' }
    $guard=New-Object Threading.Mutex($false,'Global\WindowsCare_Operation_v1')
    $owned=$false
    try {
        try { $owned=$guard.WaitOne(0) } catch [Threading.AbandonedMutexException] { $owned=$true }
        if (-not $owned) { Note 'Otra operacion de WindowsCare esta activa. Se cancela esta solicitud.'; return }
        Operation $Action {
            switch ($Action) {
                'Checkpoint' { Checkpoint }
                'SystemTemp' { Clean-Temp $true }
                'Repair' { Repair-Windows }
                'ScanDisk' { Scan-Disk }
                'Optimize' { Optimize-Disk }
                default { Defender-Action $Action }
            }
        }
    } finally { if ($owned) { $guard.ReleaseMutex() }; $guard.Dispose() }
}
function Performance {
    Note 'Programas de inicio. La lista no cuantifica impacto ni equivale a la lista de habilitados del Administrador de tareas.'
    Display (Get-CimInstance Win32_StartupCommand | Select-Object 'Name','Location')
    Note 'Revise Impacto de inicio en Administrador de tareas. No desactive antivirus, controladores ni servicios que no identifique.'
    if (Confirm '¿Abrir Administrador de tareas para revisar Inicio?') { Start-Process "$env:SystemRoot\System32\Taskmgr.exe" }
    if (Confirm '¿Abrir seleccion de unidad para optimizacion oficial?') { Run-Admin 'Optimize' }
}
function Clean-Menu {
    Write-Host "1. Temporales de esta cuenta (simulacion primero)`n2. Temporales de Windows (administrador)`n3. Vaciar papelera de esta cuenta`n0. Volver"
    switch (Read-Host 'Opcion') {
        '1' { Operation 'Temporales de cuenta actual' { Clean-Temp $false } }
        '2' { Run-Admin 'SystemTemp' }
        '3' {
            Operation 'Papelera' {
                Note 'Se elimina permanentemente TODO el contenido de la papelera de esta cuenta. No es recuperable con un punto de restauracion.'
                if (-not (Confirm '¿Vaciar la papelera?')) { return }
                if ($script:Admin) { Checkpoint } else { Run-Admin 'Checkpoint' }
                if (Confirm '¿Confirmar eliminacion permanente de la papelera?') { Clear-RecycleBin -Force -ErrorAction Stop; Note 'Papelera vaciada.' }
            }
        }
    }
}
function Defender-Menu {
    Defender-Status
    Write-Host "1. Actualizar firmas`n2. Analisis rapido`n3. Analisis completo`n4. Analisis sin conexion (REINICIA)`n5. Historial`n6. Abrir Seguridad de Windows`n0. Volver"
    switch (Read-Host 'Opcion') {
        '1' { Run-Admin 'Signatures' }
        '2' { Run-Admin 'QuickScan' }
        '3' { Run-Admin 'FullScan' }
        '4' { Run-Admin 'OfflineScan' }
        '5' { Operation 'Historial Defender' { Threat-History } }
        '6' { Start-Process 'windowsdefender:' }
    }
}
function Recommended {
    Note 'Plan propuesto: diagnostico, simulacion/limpieza de temporales de esta cuenta, actualizacion de firmas, analisis rapido. No incluye reparaciones sin indicios.'
    Write-Host 'Seleccione acciones separadas por coma: 1 diagnostico, 2 temporales, 3 firmas, 4 analisis rapido. Vacio cancela.'
    $choice=Read-Host 'Acciones'
    if ([string]::IsNullOrWhiteSpace($choice)) { return }
    if ($choice -notmatch '^\s*[1-4](\s*,\s*[1-4])*\s*$') { Note 'Seleccion invalida.'; return }
    $selected=@($choice.Split(',') | ForEach-Object {$_.Trim()} | Select-Object -Unique)
    Note ('Plan seleccionado: ' + ($selected -join ', '))
    if (-not (Confirm '¿Iniciar este plan? Cada cambio tendra su confirmacion.')) { return }
    foreach ($item in $selected) {
        switch ($item) {
            '1' { Operation 'Diagnostico' { Diagnose } }
            '2' { Operation 'Temporales de cuenta actual' { Clean-Temp $false } }
            '3' { Run-Admin 'Signatures' }
            '4' { Run-Admin 'QuickScan' }
        }
    }
}
# Un solo menu por equipo. Los trabajadores elevados usan otro mutex para evitar
# bloqueo con el menu que espera, y entre si se excluyen mediante Operation_v1.
$mutex=$null; $owns=$false
try {
    Note 'WindowsCare 1.0.1 | mantenimiento conservador | sin telemetria'
    Note "Cuenta de ejecucion: $([Security.Principal.WindowsIdentity]::GetCurrent().Name); administrador: $script:Admin"
    Note "Informe local: $script:Log"
    if ($Task -ne 'Menu') {
        Invoke-Task $Task
        Pause-Menu
    } else {
        $mutex=New-Object Threading.Mutex($false,'Global\WindowsCare_Menu_v1')
        try { $owns=$mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $owns=$true }
        if (-not $owns) { throw 'Ya hay otra ventana de WindowsCare. Cierre esta copia.' }
        do {
            Write-Host "`nWINDOWSCARE`n1. Diagnostico del equipo`n2. Limpieza segura de archivos temporales`n3. Comprobacion y reparacion de Windows`n4. Rendimiento y programas de inicio`n5. Microsoft Defender`n6. Mantenimiento recomendado`n7. Consultar informes`n0. Salir" -ForegroundColor Cyan
            $option=Read-Host 'Elija una opcion'
            try {
                switch ($option) {
                    '1' { Operation 'Diagnostico' { Diagnose } }
                    '2' { Clean-Menu }
                    '3' {
                        Write-Host "1. DISM y SFC`n2. Comprobar NTFS en linea`n0. Volver"
                        switch (Read-Host 'Opcion') { '1' { Run-Admin 'Repair' }; '2' { Run-Admin 'ScanDisk' } }
                    }
                    '4' { Operation 'Rendimiento' { Performance } }
                    '5' { Defender-Menu }
                    '6' { Recommended }
                    '7' {
                        Note "Informes: $script:LogRoot"
                        $reports=@(Get-ChildItem -LiteralPath $script:LogRoot -Filter 'Informe_*.txt' | Sort-Object LastWriteTime -Descending | Select-Object -First 20)
                        for ($i=0;$i -lt $reports.Count;$i++) { Write-Host ("{0}. {1}" -f ($i+1),$reports[$i].Name) }
                        $n=0
                        if ([int]::TryParse((Read-Host 'Numero de informe; 0 vuelve'),[ref]$n) -and $n -ge 1 -and $n -le $reports.Count) { Get-Content -LiteralPath $reports[$n-1].FullName -Encoding UTF8 | Out-Host }
                    }
                    '0' { Note 'Sesion finalizada. No se reinicia el equipo.' }
                    default { Write-Host 'Opcion no valida.' }
                }
            } catch { Note ("Accion no completada: {0}; {1}." -f $_.Exception.GetType().Name,$_.CategoryInfo.Category) }
            if ($option -ne '0') { Pause-Menu }
        } while ($option -ne '0')
    }
} catch { Write-Warning $_.Exception.Message; Pause-Menu }
finally { if ($owns -and $mutex) { $mutex.ReleaseMutex() }; if ($mutex) { $mutex.Dispose() } }
