@echo off
setlocal DisableDelayedExpansion
set "WC_SCRIPT=%~dp0WindowsCare.ps1"
set "WC_PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "WC_PS=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%WC_SCRIPT%" (
  echo No se encontro WindowsCare.ps1 junto a este lanzador.
  pause
  exit /b 1
)
"%WC_PS%" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%WC_SCRIPT%"
set "WC_RESULT=%ERRORLEVEL%"
if not "%WC_RESULT%"=="0" (
  echo PowerShell finalizo con error %WC_RESULT%. Revise la salida anterior.
  pause
)
endlocal & exit /b %WC_RESULT%
